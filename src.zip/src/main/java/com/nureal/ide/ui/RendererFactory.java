package com.nureal.ide.ui;

import java.time.temporal.Temporal;
import java.util.Locale;

import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

/**
 * Escolhe e instala o {@link TableCellRenderer} de cada coluna da grade de
 * resultados, classificando-a em um dos 6 grupos coloridos (pelo NOME DO
 * TIPO SQL real — {@link ResultTableModel#sqlType(int)} — com fallback pela
 * classe Java quando o tipo nao e conhecido, mais uma heuristica de NOME
 * para identificadores):
 *
 * 1) IDENTIFICADORES (id, *_id, uuid/guid) -&gt; {@link IdentifierCellRenderer}
 * 2) NUMERICOS (INT/DECIMAL/FLOAT/...)     -&gt; {@link NumberCellRenderer}
 * 3) TEMPORAIS (DATE/TIME/TIMESTAMP/...)   -&gt; {@link TemporalCellRenderer}
 * 4) LOGICOS (BOOLEAN/BIT/classe Boolean)  -&gt; {@link BooleanCellRenderer}
 * 5) BINARIOS/COMPLEXOS (BLOB/JSON/XML/...) -&gt; {@link BinaryCellRenderer}
 * 6) TEXTUAIS (VARCHAR/TEXT/...) — tambem o DEFAULT -&gt; {@link TextCellRenderer}
 *
 * IMPORTANTE: o grupo e decidido SEMPRE pelo TIPO DE DADO real da coluna
 * (tipo SQL ou, na falta dele, a classe Java) — NUNCA pelo NOME da coluna
 * sozinho (ex.: uma coluna chamada "status" armazenada como INT aparece com a
 * MESMA cor de qualquer outra coluna INT/NUMERICA, nao ganha um tratamento
 * especial so por causa do nome). Pedido explicito do usuario, que reportou
 * uma coluna "status" (na verdade um INT com codigos 1/2/3 de dominio, sem
 * relacao com verdadeiro/falso) ganhando cores desencontradas de um pill de
 * "enum" — o esperado era a MESMA cor de qualquer outra coluna numerica. A
 * UNICA excecao onde o NOME de uma coluna entra na conta e a heuristica de
 * identificador ("id"/"*_id"/uuid, ver {@link #isGenericIdName}/{@link #isUuidName}),
 * que e um refinamento DENTRO dos grupos NUMERIC/IDENTIFIER, nao um grupo
 * proprio como o antigo "status" era.
 *
 * Dentro do grupo 6 ha ainda um refinamento so de CONTEUDO (nao de tipo SQL):
 * uma textual com poucos valores curtos que se repetem (ex.: RECEITA/DESPESA)
 * ganha {@link BadgeCellRenderer} (pill colorido) em vez do texto plano do
 * {@link TextCellRenderer} — ver {@link EnumColumnDetector}.
 *
 * A classificacao acontece UMA VEZ POR COLUNA, quando a grade e montada
 * ({@link #installOn}) — nao a cada celula pintada — e os renderers em si
 * sao instancias UNICAS e sem estado (compartilhadas por todas as colunas do
 * mesmo grupo, em todas as grades da aplicacao), nunca recriadas.
 */
final class RendererFactory {

    /**
     * Chave de client property (ver {@code JComponent#putClientProperty}) sob
     * a qual {@link ResultGrid} guarda o {@link ColumnMetadataResolver} desta
     * tabela especifica — {@link AbstractTypedCellRenderer} le esta property
     * a cada celula pintada pra saber se a coluna e chave primaria/estrangeira
     * de verdade (metadados do banco), sem precisar que os renderers
     * (instancias UNICAS e compartilhadas entre todas as grades) guardem
     * nenhum estado por tabela.
     */
    static final String KEY_METADATA_RESOLVER = "nureal.columnMetadataResolver";

    private static final IdentifierCellRenderer IDENTIFIER = new IdentifierCellRenderer();
    private static final NumberCellRenderer NUMBER = new NumberCellRenderer();
    private static final TemporalCellRenderer TEMPORAL = new TemporalCellRenderer();
    private static final BooleanCellRenderer LOGICAL = new BooleanCellRenderer();
    private static final BinaryCellRenderer BINARY = new BinaryCellRenderer();
    private static final TextCellRenderer TEXTUAL = new TextCellRenderer();
    private static final BadgeCellRenderer BADGE = new BadgeCellRenderer();

    private static final String[] TEMPORAL_PREFIXES =
            {"TIMESTAMPTZ", "TIMESTAMP", "DATETIME", "DATE", "TIME", "YEAR"};
    private static final String[] BINARY_PREFIXES =
            {"LONGBLOB", "MEDIUMBLOB", "TINYBLOB", "BLOB", "CLOB", "NCLOB", "BYTEA",
                    "JSONB", "JSON", "XML", "VARBINARY", "BINARY", "GEOMETRY"};
    private static final String[] LOGICAL_PREFIXES = {"BOOLEAN", "BOOL", "BIT"};
    private static final String[] NUMERIC_PREFIXES =
            {"INT", "INTEGER", "BIGINT", "SMALLINT", "TINYINT", "MEDIUMINT", "FLOAT", "DOUBLE",
                    "DECIMAL", "NUMERIC", "REAL", "DEC", "FIXED", "NUMBER", "MONEY", "SMALLMONEY"};

    private RendererFactory() {
    }

    enum Group { IDENTIFIER, NUMERIC, TEMPORAL, LOGICAL, BINARY, TEXTUAL }

    /** Classifica e instala o renderer (e, para colunas TEMPORAIS, o editor) de cada coluna de {@code table}. */
    static void installOn(javax.swing.JTable table, ResultTableModel model) {
        for (int c = 0; c < table.getColumnModel().getColumnCount(); c++) {
            TableColumn column = table.getColumnModel().getColumn(c);
            int modelColumn = column.getModelIndex();
            Group group = classify(model.sqlType(modelColumn), model.getColumnClass(modelColumn),
                    model.getColumnName(modelColumn));
            if (group == Group.TEXTUAL && EnumColumnDetector.isEnumLike(model, modelColumn)) {
                // Coluna textual "de categoria" (poucos valores curtos que se
                // repetem, ex.: RECEITA/DESPESA) — pill colorido em vez de
                // texto plano. So um refinamento visual DENTRO do grupo
                // TEXTUAL (ver classify()); nao muda alinhamento nem nenhuma
                // outra regra dos 6 grupos.
                column.setCellRenderer(BADGE);
            } else {
                column.setCellRenderer(rendererFor(group));
            }
            if (group == Group.TEMPORAL) {
                // Precisa de um editor PROPRIO (ver TemporalCellEditor): o
                // editor generico padrao do JTable mostra/espera um formato
                // diferente do que a grade exibe e nao consegue reconstruir
                // tipos java.time.* (LocalDate/LocalDateTime nao tem
                // construtor(String)) — edicao de data falhava em silencio.
                // Instancia NOVA por coluna: guarda estado por edicao em
                // andamento (classe alvo, valor parseado), nao pode ser
                // compartilhada entre colunas/grades.
                column.setCellEditor(new TemporalCellEditor());
            }
        }
    }

    static TableCellRenderer rendererFor(Group group) {
        return switch (group) {
            case IDENTIFIER -> IDENTIFIER;
            case NUMERIC -> NUMBER;
            case TEMPORAL -> TEMPORAL;
            case LOGICAL -> LOGICAL;
            case BINARY -> BINARY;
            case TEXTUAL -> TEXTUAL;
        };
    }

    /**
     * Classifica a coluna em um dos 6 grupos. Prioridade: tipos
     * temporais/binarios/logicos pelo NOME DO TIPO SQL primeiro
     * (inequivocos); depois o nome da coluna para identificadores, mas com
     * duas regras DIFERENTES conforme o sinal do nome (ver
     * {@link #isUuidName}/{@link #isGenericIdName} abaixo); por fim
     * numericos pelo tipo SQL, com fallback pela classe Java quando o tipo
     * SQL nao estiver disponivel.
     */
    static Group classify(String sqlType, Class<?> cls, String columnName) {
        String type = normalizeType(sqlType);
        String name = columnName == null ? "" : columnName.toLowerCase(Locale.ROOT);

        if (!type.isEmpty()) {
            if (startsWithAny(type, TEMPORAL_PREFIXES)) {
                return Group.TEMPORAL;
            }
            if (startsWithAny(type, BINARY_PREFIXES)) {
                return Group.BINARY;
            }
            if (startsWithAny(type, LOGICAL_PREFIXES)) {
                return Group.LOGICAL;
            }
        }

        boolean numericType = !type.isEmpty() && startsWithAny(type, NUMERIC_PREFIXES);
        boolean numericClass = Number.class.isAssignableFrom(cls);

        // "uuid"/"guid" no nome: sinal inequivoco de identificador opaco
        // independente do tipo fisico de armazenamento (muitos bancos
        // guardam UUID como CHAR/VARCHAR mesmo).
        if (isUuidName(name)) {
            return Group.IDENTIFIER;
        }
        // "id"/"*_id" no nome: SO conta como identificador de verdade quando
        // o valor tambem E numerico (autoincrement/chave de verdade). Uma
        // coluna "*_id" armazenada como TEXTO PURO (VARCHAR/CHAR/TEXT) e sem
        // cara de UUID e, na pratica, quase sempre um identificador de
        // NEGOCIO/externo (ex.: client_order_id copiado de outro sistema) —
        // nao uma chave desta tabela — entao cai no fluxo normal abaixo e
        // termina classificada como TEXTUAL, igual qualquer outra coluna de
        // texto. Pedido explicito do usuario: uma "*_id" que e texto e nem
        // faz parte da chave da tabela deve ser tratada como texto normal,
        // nao ganhar o destaque/alinhamento de identificador so pelo nome.
        if (isGenericIdName(name) && (numericType || numericClass)) {
            return Group.IDENTIFIER;
        }
        if (numericType || numericClass) {
            return Group.NUMERIC;
        }
        // Fallback pela classe Java quando o nome do tipo SQL nao ajudou.
        if (isTemporalClass(cls)) {
            return Group.TEMPORAL;
        }
        if (cls == Boolean.class) {
            return Group.LOGICAL;
        }
        return Group.TEXTUAL;
    }

    private static boolean isGenericIdName(String lowerCaseName) {
        return lowerCaseName.equals("id") || lowerCaseName.endsWith("_id");
    }

    private static boolean isUuidName(String lowerCaseName) {
        return lowerCaseName.contains("uuid") || lowerCaseName.contains("guid");
    }

    private static boolean isTemporalClass(Class<?> cls) {
        return java.util.Date.class.isAssignableFrom(cls) || Temporal.class.isAssignableFrom(cls);
    }

    /** Tipo SQL em maiusculas, sem sufixo de precisao/escala (ex.: "DECIMAL(10,2)" -&gt; "DECIMAL"). */
    private static String normalizeType(String sqlType) {
        if (sqlType == null) {
            return "";
        }
        String t = sqlType.toUpperCase(Locale.ROOT).trim();
        int paren = t.indexOf('(');
        return (paren > 0) ? t.substring(0, paren).trim() : t;
    }

    private static boolean startsWithAny(String type, String[] prefixes) {
        for (String prefix : prefixes) {
            if (type.equals(prefix) || type.startsWith(prefix + " ")) {
                return true;
            }
        }
        return false;
    }
}
